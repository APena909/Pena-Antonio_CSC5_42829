/* 
 * File:   main.cpp
 * Author: Antonio Pena
 * Created on March 2, 2016, 10:00 AM
 * Purpose: Calculate percentages of federal budgets for NASA & Military.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    float budg;//Budget amount spent
    float tfbudg;//Total Federal Budget
    
    //Prompt for input
    cout<<"Input the estimated budget spent "<<endl;
    cin>>budg;
    
    //Calculate the percentage
    
    //Output the results
    
    //Exit Stage Right!

    return 0;
}

