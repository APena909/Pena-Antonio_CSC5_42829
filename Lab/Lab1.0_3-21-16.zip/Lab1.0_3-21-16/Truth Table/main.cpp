/* 
 * File:   main.cpp
 * Author: rcc
 *
 * Created on March 21, 2016, 9:45 AM
 */

#include <cstdlib>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    return 0;
}

